# Admin
Module 7
Lesson 4
Lesson Title: Building, Testing, and Improving Designs
# Template
[start of lesson]
# 7.4
# Building, Testing, and Improving Designs
## Learning Objectives
By the end of this session, you'll be able to:
- Implement robot designs in either virtual or physical environments following structured procedures
- Conduct systematic tests to evaluate robot performance against design goals
- Apply test results to make specific, data-driven improvements to robot designs
## Lesson Podcast Discussion: Systematic Testing Approaches for Robotics
Systematic testing is like being a robot detective! When engineers build robots, they don't just hope they work - they create step-by-step tests to see exactly how well their robots perform. These tests give them real numbers and observations instead of just guesses. For example, if you're building a robot that follows lines, you might test how fast it can go before it loses the line, or how well it handles sharp turns versus gentle curves. By collecting this information carefully, engineers can pinpoint exactly what needs to be fixed or improved. It's like having a map that shows you exactly where to dig for treasure, instead of just randomly digging holes all over the beach!

## Implementation Techniques
This section covers the foundational approaches to turning robot designs into functional prototypes, whether in virtual or physical environments.
### Build Planning and Preparation
Before you start building your robot, proper planning saves time and prevents frustration. First, gather all your materials and components in one place and check that nothing is missing. Make a list of tools you'll need, from basic screwdrivers to specialized items like wire strippers. 

Set up your workspace with good lighting and enough room to spread out. Many builders find it helpful to use small containers to organize tiny parts like screws or sensors. This prevents the dreaded "where did that tiny screw go?" problem!

Finally, review your design plans and create a step-by-step build sequence. Think about which parts need to be assembled first - usually the main structure or chassis comes before adding motors, and electronics typically go in last to avoid damage during construction.

### Assembly Procedures and Best Practices
When assembling your robot, patience is your best friend! Start by following your build sequence and don't rush. For mechanical parts, make sure connections are secure but not overtightened, which can strip screws or crack plastic parts. 

When working with electronics, be extra careful with wiring. Color-code your wires if possible (red for power, black for ground) and use labels or a simple diagram to keep track of connections. Always double-check electrical connections before powering up your robot to avoid short circuits.

Take photos as you build - these can be incredibly helpful if you need to disassemble something later. And remember, it's normal to make adjustments as you go. Sometimes what looks good on paper needs small changes when built in real life.

### Virtual vs. Physical Implementation Considerations
Building robots virtually (in simulation) and physically each have their own advantages. Virtual robots let you test ideas quickly without spending money on parts. Programs like Tinkercad Circuits or virtual robot simulators let you experiment freely and make mistakes without breaking anything. They're perfect for testing basic concepts or when physical materials aren't available.

Physical robots, however, give you hands-on experience with real-world challenges like friction, battery limitations, and sensor accuracy that simulations might simplify. They also provide the satisfaction of creating something you can actually touch and show to others.

For example, a weather station robot might work perfectly in a simulation where sensors always give perfect readings. But in the real world, rain might interfere with sensors or wind might affect stability. The Mars rover teams at NASA use both approaches - they test extensively in virtual environments first, then build physical prototypes to discover real-world challenges before the final rover is sent to Mars.

If possible, a combined approach works best: test your initial ideas in simulation to work out major problems, then build physically with more confidence. Remember that a robot that works perfectly in simulation might still face unexpected challenges in the real world!

## **Activity 1: Test Plan Development and Execution**
Create a comprehensive test plan for your robot design that includes at least three specific test cases with clearly defined procedures, expected results, and data collection methods. Implement this plan by conducting tests and recording your observations in a structured format that will facilitate analysis.
## Systematic Testing Methods
This section explores structured approaches to evaluating robot performance against design goals and specifications.
### Designing Test Protocols
Creating good test protocols is like writing a recipe that anyone could follow to check if your robot works properly. Start by identifying exactly what you want to test - is it speed, accuracy, battery life, or something else? For each aspect, create a specific test case with clear steps.

For example, if testing a line-following robot, your protocol might include: "Place robot at the starting line. Start timer when robot begins moving. Stop timer when robot completes the entire course. Record time and count how many times the robot lost the line."

Good test protocols should be repeatable (you can do them multiple times with similar results), measurable (giving you numbers or clear observations), and fair (testing under consistent conditions). Include details about the testing environment too - lighting, surface type, and other factors that might affect performance.

### Data Collection and Documentation
Collecting data is how we turn observations into useful information. Create simple tables or charts to record your test results. For example:

| Test Run | Completion Time | Number of Errors | Battery Level |
|----------|----------------|-----------------|---------------|
| Run 1    | 45 seconds     | 2               | Full          |
| Run 2    | 48 seconds     | 3               | 75%           |

Don't just write down numbers - also note observations that might explain results: "Robot struggled at the sharp turn near the end" or "Motor seemed to slow down after 2 minutes of operation."

Taking photos or videos during testing can be extremely helpful. They capture details you might miss and provide evidence of how your robot performed. Many students find it helpful to keep a testing journal with dates, results, and ideas for improvements all in one place.

### Performance Metrics and Benchmarks
Performance metrics are the specific measurements we use to evaluate success. For a delivery robot, metrics might include how accurately it reaches destinations, how many packages it can carry, or how long its battery lasts.

To create meaningful benchmarks (standards for success), consider:
1. Minimum requirements: What's the bare minimum your robot must do to be considered functional?
2. Target goals: What would make your robot perform well enough for its intended purpose?
3. Stretch goals: What would make your robot perform exceptionally well?

For example, a line-following robot might have these benchmarks:
- Minimum: Complete the course without leaving the line for more than 3 seconds
- Target: Complete the course in under 1 minute with no more than 2 errors
- Stretch: Complete the course in under 45 seconds with zero errors

Having clear metrics and benchmarks helps you objectively determine if your robot is meeting expectations and where improvements are needed.

## Stop and reflect

**CHECKPOINT:** Consider a test where your robot didn't perform as expected. What did this failure teach you about your design assumptions? Reflect on how this unexpected outcome revealed gaps in your understanding of the problem.

## Problem Analysis and Troubleshooting
This section covers methodical approaches to identifying and resolving issues discovered during robot testing.
### Identifying Failure Points
When your robot isn't working correctly, finding exactly where the problem lies is the first step to fixing it. Start by breaking down your robot into systems: mechanical (structure, moving parts), electrical (power, wiring), and programming (code, logic).

Test each system separately when possible. For mechanical issues, check if parts move freely, if anything is loose, or if components are aligned properly. For electrical problems, verify connections are secure, batteries are charged, and no wires are damaged. For programming issues, try running simplified versions of your code to isolate which parts work and which don't.

A helpful technique is the "half-split" method: if you're not sure which of ten components has a problem, test in the middle (component #5). If that works, the problem is in components #6-10. If it doesn't, the problem is in components #1-5. Keep dividing the suspicious area in half until you find the exact failure point.

Remember to check the obvious things first! Many "complex" problems turn out to be simple issues like a loose wire, low battery, or a sensor that's been bumped out of position.

### Root Cause Analysis
Finding the root cause means looking beyond the obvious symptom to discover why the problem happened in the first place. For example, if your robot keeps veering to the left, the symptom is the turning, but the root cause could be:
- Uneven wheel sizes
- More friction on one side
- Unbalanced weight distribution
- A programming error in the steering calculations
- A motor that's weaker on one side

A useful technique is the "Five Whys" method. Start with the problem and keep asking "why" until you reach the fundamental cause. For example:
1. Why is the robot veering left? Because the right wheel is turning faster.
2. Why is the right wheel turning faster? Because the left wheel has more resistance.
3. Why does the left wheel have more resistance? Because the wheel isn't aligned properly.
4. Why isn't the wheel aligned? Because the mounting bracket is bent.
5. Why is the bracket bent? Because the material is too thin for the robot's weight.

Now you know you need a stronger bracket, not just a programming fix that compensates for the turning!

### Systematic Debugging Approaches
Debugging is like being a detective solving a mystery. The key is to be methodical rather than making random changes and hoping they work.

For mechanical debugging:
- Isolate moving parts and test them individually
- Look for interference between components
- Check for loose or overtightened connections
- Verify that parts are properly aligned

For electrical debugging:
- Test power sources first (batteries, connections)
- Use a multimeter if available to check voltages
- Verify that all connections are secure
- Look for shorts or damaged wires

For programming debugging:
- Add "debug prints" to show values at different points in your code
- Comment out sections to see if problems disappear
- Test simple commands to verify basic functionality
- Check sensor readings to ensure they're providing accurate data

Document everything you try and the results you observe. This prevents you from trying the same unsuccessful fix twice and helps you spot patterns that might reveal the underlying problem.

## Design Iteration Principles
This section explores the process of making targeted improvements based on test results to enhance robot performance.
### Making Targeted Improvements
Making targeted improvements means changing specific parts of your design based on what your tests revealed, rather than starting over completely. Think of it as precision surgery instead of demolishing and rebuilding a house!

Start by connecting each problem directly to a specific improvement. For example:
- If tests show your robot is too slow, you might upgrade motors or reduce weight
- If battery life is too short, you might add a larger battery or optimize power usage in your code
- If sensors are giving inconsistent readings, you might reposition them or add shielding from interference

Make one change at a time whenever possible. This way, you'll know exactly which change fixed (or didn't fix) each problem. If you change five things at once and the robot improves, you won't know which change made the difference!

Keep your original design goals in mind when making improvements. Sometimes fixing one problem might create trade-offs with other aspects of performance. For example, adding a bigger battery might improve run time but also make your robot heavier and slower.

### Prioritizing Changes
Not all improvements are equally important or equally easy to implement. Prioritizing helps you focus your time and resources effectively.

A helpful tool is the impact/effort matrix - a simple chart with four sections:
1. High impact, low effort: Do these first! (Quick wins)
2. High impact, high effort: Plan these carefully (Major projects)
3. Low impact, low effort: Do if you have time (Easy fixes)
4. Low impact, high effort: Avoid these (Not worth it)

For example, if your garden-monitoring robot keeps getting stuck in mud:
- High impact, low effort: Adding wider wheels (quick win)
- High impact, high effort: Redesigning the entire movement system (major project)
- Low impact, low effort: Making the robot more colorful (easy but not helpful)
- Low impact, high effort: Building a completely new robot (not worth it)

Also consider dependencies between changes. Some improvements might need to happen in a specific order. For example, you might need to strengthen your robot's structure before adding heavier components.

Finally, focus on fixing critical flaws before making optional enhancements. If your robot can't complete its basic task, making it look cooler or adding extra features should wait until the fundamental functionality works properly.

### Documenting Design Evolution
Keeping track of how your design changes over time is incredibly valuable. Create a design log that records:
- What version of the design you're working on (v1, v2, etc.)
- What specific changes you made in each version
- Why you made those changes (which problems they address)
- How the changes affected performance (with test results)
- Any unexpected consequences of the changes

Include photos or diagrams of each version if possible. This visual record makes it easier to see how your design has evolved and might help you identify patterns or issues.

Good documentation also helps if you need to "roll back" to a previous version because a change didn't work as expected. Instead of trying to remember how things were before, you'll have clear records to guide you.

## **Activity 2: Iteration Documentation**
Document improvements between at least two versions of your robot design using before/after comparisons. Create a table or chart that clearly shows what specific aspects were changed, why those changes were made based on test data, and how each change impacted performance. Include visual documentation if possible.
## Verification and Validation
This section covers methods for confirming that the improved design meets requirements and performs as expected in realistic conditions.
### Confirming Requirements Are Met
Verification is the process of checking that your robot meets all the specific requirements you established at the beginning of your project. Think of it as going through a checklist to make sure nothing has been forgotten.

Start by reviewing your original design requirements. For each requirement, create a specific test that will verify whether it's been met. For example:
- If a requirement was "robot must be able to navigate around obstacles," your verification test might involve placing objects in the robot's path and confirming it successfully avoids them.
- If a requirement was "robot must operate for at least 30 minutes on a single charge," your verification would involve timing a complete run cycle.

Create a simple verification table with columns for each requirement, the test method, and whether it passed or failed. This gives you a clear picture of which requirements have been satisfied and which still need work.

Remember that verification is objective - a requirement is either met or it isn't. This helps you make clear decisions about whether your robot is ready for real-world use.

### Validating Real-World Performance
Validation goes beyond checking specific requirements to evaluate how well your robot performs its intended function in realistic conditions. While verification asks "Did we build the robot right?", validation asks "Did we build the right robot?"

To validate your robot, test it in environments that closely match where it will actually be used. For example:
- If you've built a line-following robot for a competition, practice on courses similar to the competition track
- If you've built a robot to help around the house, test it in actual rooms with real furniture and obstacles

Validation often reveals unexpected challenges that didn't show up in controlled testing. Maybe your robot works perfectly on smooth surfaces but struggles on carpet, or works well in bright light but gets confused in shadows.

Collect feedback from potential users if possible. If others will be operating your robot, have them try it out and share their experiences. Their perspective might reveal usability issues you hadn't considered.

### Final Design Documentation
Comprehensive documentation of your final design serves multiple purposes: it helps others understand your work, allows you to recreate your robot if needed, and provides a foundation for future improvements.

Your final documentation should include:

1. Design overview: A high-level description of what your robot does and how it works
2. Detailed specifications: Dimensions, weight, materials, components used
3. Assembly instructions: Step-by-step guide with diagrams or photos
4. Code documentation: Well-commented code with explanations of key functions
5. Performance data: Results from your final tests showing how well the robot performs
6. Design history: Brief summary of major changes made during development
7. Known limitations: Honest assessment of any remaining issues or constraints
8. Future improvements: Ideas for how the design could be enhanced further

Make your documentation clear enough that someone with similar skills could understand and potentially recreate your robot. Use simple language, include plenty of visuals, and organize information logically.

Remember that good documentation is valuable even after your project is complete - it might help you or others build on your work in the future!

## Stop and reflect

**CHECKPOINT:** How did your understanding of the problem change through the testing and improvement process? Consider how your perception of what makes an effective solution evolved based on empirical evidence rather than initial assumptions.

### **Check your understanding**
Which approach to design improvement is most effective after initial testing?
A. Completely redesigning the robot from scratch based on test results
B. Making multiple major changes simultaneously to address all issues at once
C. Making targeted, incremental changes based on specific test data, then retesting
D. Focusing only on the programming aspects since mechanical issues are too difficult to fix
Choose your answer and check it below.
The correct answer is C. Making targeted, incremental changes based on specific test data, then retesting. The most effective approach to design improvement is to make specific, data-driven changes that address identified issues one at a time, followed by retesting. This methodical approach allows you to clearly see the impact of each change and avoids introducing new problems through overly broad modifications. If you chose a different answer, remember that incremental improvement allows for better tracking of cause and effect relationships between changes and performance.
## Key Takeaways
- Systematic testing provides objective data about design performance that guides improvements, enabling evidence-based decision making rather than guesswork
- Effective troubleshooting requires identifying root causes rather than just addressing symptoms, which leads to more permanent and comprehensive solutions
- Design iteration is a normal and expected part of the engineering process that leads to improved solutions, not an indication of initial failure
[End of Lesson]
## Instructional designer notes of lesson 7.4
**This lesson fits into the the overall module of 7 in the following ways:**
-