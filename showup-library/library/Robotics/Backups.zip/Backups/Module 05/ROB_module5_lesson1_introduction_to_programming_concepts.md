# Admin
Module 5
Lesson 1
Lesson Title: Introduction to Programming Concepts
# Template
[start of lesson]
# 5.1
# Introduction to Programming Concepts
## Learning Objectives
By the end of this session, you'll be able to:
- Define what programming is within the input-processing-output framework
- Explain how programming connects to robotics
- Identify key programming terminology and concepts

## Lesson Podcast Discussion: Understanding Programming Fundamentals
This podcast explores how programming serves as a communication bridge between humans and machines, focusing on the input-processing-output framework as a foundation for robotic programming.

## What is Programming?
Programming is the process of creating a set of instructions that tell a computer or machine how to perform specific tasks. These instructions, called code, are written in special languages that computers can understand. In essence, programming is how we communicate with machines to make them do what we want.

When we program, we're essentially translating human intentions into a format that machines can execute. Just as we use natural languages like English to communicate with other people, we use programming languages to communicate with computers and robots.

### Core Programming Principles
Programming follows several fundamental principles:
- **Precision**: Unlike human communication, programming requires exact instructions
- **Logic**: Instructions follow logical patterns and sequences
- **Structure**: Code is organized in a specific structure determined by the programming language
- **Problem-solving**: Programming is fundamentally about breaking down problems into solvable steps

## Programming in the Input-Processing-Output Framework
The input-processing-output (IPO) framework provides a clear way to understand how programming works, especially in robotics:

1. **Input**: The program receives data from various sources, such as sensors, user commands, or stored information
2. **Processing**: The program performs operations on this data according to its instructions
3. **Output**: The program produces results based on the processing, which might be movement, displays, sounds, or other actions

### Robotics Application
In robotics, this framework comes to life:
- **Input**: Sensors detect the environment (light sensors, touch sensors, cameras)
- **Processing**: Code determines what to do with the sensor data
- **Output**: Motors move, lights turn on, sounds play, or displays show information

This framework helps us visualize how robots interact with their environment through our programming instructions.

### Real-World Example: School Security System
Let's look at how the input-processing-output framework works in a school security system:

- **Input**: Motion sensors detect movement in hallways after school hours
- **Processing**: The security program checks: Is it after hours? Is this movement in a restricted area? Is there a scheduled event?
- **Output**: If unauthorized movement is detected, the system might turn on lights, sound an alarm, or send a notification to security staff

This same framework applies whether we're programming a simple robot that follows a line or a complex robot that navigates a building.

## Activity 1: Algorithmic Thinking in Daily Life

**Activity 1: Creating Daily Task Instructions**
Think about the process of making a peanut butter and jelly sandwich. Write step-by-step instructions that would allow someone who has never seen a sandwich to make one perfectly. Be as precise as possible, assuming the person will follow your instructions exactly as written. After writing your instructions, review them and identify any steps that might be ambiguous or assume prior knowledge. This exercise demonstrates algorithmic thinking—breaking down a process into precise, sequential steps—which is fundamental to programming.

## Key Programming Concepts
Programming involves several core concepts that appear across different programming languages:

### Variables
Variables are like containers that store information. They can hold numbers, text, or more complex data. In robotics, variables might store sensor readings, motor speeds, or position coordinates.

### Conditions
Conditions allow programs to make decisions based on certain criteria. "If-then-else" statements help robots respond differently depending on their environment.
- Example: If the light sensor detects darkness, then turn on the headlight, else keep the headlight off.

### Loops
Loops allow programs to repeat actions multiple times. They're essential for tasks that require repetition without writing the same code over and over.
- Example: A loop might make a robot check its distance sensor repeatedly while moving forward.

### Functions
Functions are reusable blocks of code that perform specific tasks. They help organize code and prevent repetition.
- Example: A "turn90Degrees" function could contain all the steps needed for a robot to make a precise 90-degree turn.

### Programming Across Different Robot Platforms
The same programming concepts work across many different types of robots:

- **LEGO Robots**: Use variables to store light sensor readings, conditions to decide when to turn, and loops to keep checking the path
- **Drone Robots**: Use variables to track height, conditions to avoid obstacles, and functions to perform specific flight maneuvers
- **Robot Arms**: Use variables to remember positions, conditions to check if objects are present, and loops to repeat pick-and-place actions

While the robots look different, the programming concepts remain the same!

## Stop and reflect

**CHECKPOINT:** Think about the last time you gave someone directions to complete a task. How clear and precise were your instructions? Consider how the person might have misinterpreted your directions if they were ambiguous, much like a robot would fail to execute imprecise programming instructions.

## Introduction to Block-Based Programming
Block-based programming provides a visual approach to coding that's especially helpful for beginners:

### Visual Programming Environment
Instead of typing text commands, block-based programming lets you drag and drop colorful blocks that represent different programming instructions. These blocks fit together like puzzle pieces, making it easy to see how code flows.

### Benefits for Learning
- **Reduced syntax errors**: Blocks only fit together in ways that make logical sense
- **Visual feedback**: You can see the structure of your program at a glance
- **Focus on concepts**: You can learn programming logic without worrying about typos or punctuation
- **Immediate testing**: Many block environments let you run your code instantly to see results

### Examples in Robotics
Several platforms use block-based programming for robotics:
- Scratch
- LEGO MINDSTORMS
- VEX Blocks
- micro:bit MakeCode

These platforms make it easier to start programming robots without extensive coding knowledge.

## Programming Challenges in the Real World
When programming robots, engineers face several challenges:

### Dealing with Unpredictable Environments
Unlike computers that operate in controlled settings, robots interact with the real world, which can be unpredictable:
- Floors might be slippery or uneven
- Lighting conditions can change
- Objects might move unexpectedly

To handle these challenges, programmers:
- Add extra checks in their code (like "if the robot is tilting, slow down")
- Include safety measures (like "if something is too close, stop immediately")
- Create backup plans (like "if the main path is blocked, try this other route")

### From Code to Action: Bridging the Gap
Sometimes a robot doesn't move exactly as programmed because:
- Motors might not be perfectly matched in strength
- Sensors might give slightly different readings each time
- Physical parts like wheels can wear down over time

Programmers solve these problems by:
- Calibrating sensors regularly
- Testing programs in different conditions
- Adding code that can adjust to small differences in how the robot performs

![Robot Programming Diagram](https://example.com/robot_programming_diagram.jpg)
*This diagram shows how programming instructions translate to physical robot actions*

### Check your understanding
Which of the following best describes programming in the context of robotics?
A. Writing code in any language
B. Creating art with computers
C. Giving precise instructions that connect inputs to outputs
D. Making websites

Choose your answer and check it below.

The correct answer is C. Giving precise instructions that connect inputs to outputs. Programming in robotics is about creating instructions that tell the robot how to process inputs and create appropriate outputs. If you chose a different answer, remember that while programming can involve writing code (A), creating digital art (B), or making websites (D), in robotics specifically it's about creating the instructions that allow robots to interpret their environment and respond appropriately.

## Key Takeaways
- Programming is giving precise instructions to computers, requiring clear, logical steps that machines can follow
- In robotics, programming connects inputs to outputs, allowing robots to sense their environment and respond accordingly
- Block-based programming provides a visual way to create instructions, making it easier to learn programming concepts without complex syntax

[End of Lesson]
## Instructional designer notes of lesson 5.1
**This lesson fits into the the overall module of Speaking Robot Language in the following ways:**
- It establishes the foundational concepts of programming that will be built upon in subsequent lessons
- It introduces the input-processing-output framework that will be applied throughout all robot programming activities
- It prepares students for the hands-on block programming they'll do later in the module
- It connects everyday instructions to programming concepts, making abstract ideas more concrete

**This lesson could be followed by this game:**
Sequencer game: Students are presented with a set of programming blocks representing steps in a simple robot task (like navigating a maze or picking up an object). They must arrange these blocks in the correct order to accomplish the task. For example, the game could show scrambled blocks like "Move forward," "Check distance sensor," "Turn right," and "If obstacle detected" that need to be arranged to create a working algorithm for a robot to navigate around an obstacle.